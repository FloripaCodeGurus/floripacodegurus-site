
# error:
1s
Run aws-actions/configure-aws-credentials@v4
  with:
    aws-access-key-id: ***
    aws-secret-access-key: ***
    aws-region: ***
    audience: sts.amazonaws.com
    output-env-credentials: true
Error: The request signature we calculated does not match the signature you provided. Check your AWS Secret Access Key and signing method. Consult the service documentation for details.
Run aws-actions/configure-aws-credentials@v4
  with:
    aws-access-key-id: ***
    aws-secret-access-key: ***
    aws-region: ***
    audience: sts.amazonaws.com
    output-env-credentials: true
1s
Run aws-actions/configure-aws-credentials@v4
  with:
    aws-access-key-id: ***
    aws-secret-access-key: ***
    aws-region: ***
    audience: sts.amazonaws.com
    output-env-credentials: true
Error: The request signature we calculated does not match the signature you provided. Check your AWS Secret Access Key and signing method. Consult the service documentation for details.
0s


# Actions secrets and variables
## Secrets:
AWS_ACCESS_KEY_ID :AKIASUNMFBORBYO7FMYG 
AWS_REGION: sa-east-1
AWS_SECRET_ACCESS_KEY: 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
EC2_HOST: ec2-54-94-54-29.sa-east-1.compute.amazonaws.com
EC2_USERNAME:fcgurus-site-sp-east-1-prd
Instance ID: i-006ae61f3ad1d6aba
FIRST_NAME: Fabio
LAST_NAME: Classo
USER_EMAIL: administrcao@floripacodegurus.com.br
USER_NAME: JohnDoe
USER_PASSWORD: "JohnDoeSecurePassword#2025"
sa_east_1_idrsa_key

54.94.54.29
ssh -i fcgurus-sp-east-1-key.pem ec2-user@ec2-54-94-54-29.sa-east-1.compute.amazonaws.com
chmod 400 fcgurus-sp-east-1-key.pem
ec2-54-94-54-29.sa-east-1.compute.amazonaws.com
ssh -i fcgurus-sp-east-1-key.pem ec2-user@54.94.54.29

ssh -i fcgurus-sp-east-1-key-openssh.pem ec2-user@ec2-54-94-54-29.sa-east-1.compute.amazonaws.com

# Generate public key from your private key
ssh-keygen -y -f fcgurus-sp-east-1-key-openssh.pem > fcgurus-sp-east-1-key-openssh.pub

# Check the public key content
cat fcgurus-sp-east-1-key-openssh.pub

-----BEGIN PRIVATE KEY-----
MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC+ApYf6AzX3R04
aqoIA10lILtG9OpL0X2AqkWuIUJEcnCreHCK6zp1MPLtPKlXI7eKCCSt356MEjQz
DHO5PmPjvuZkDO1t45DG3+uB6mIvyR5I1gfLcEECsKmJjVvlyLKBXKMHC6l4l5jp
F4rL4Dv/GtSU/HctRyeAfbgxLDHrceWjiX8nDNRvNHvPoerNaWJlGwRObtSJO53X
a/DJ7mQ/8lFCvDYo5D8vVMJo5efsWulHFB0gz5duXheaJ2Yp6H3gZCTMl0nkWqBv
3wGelBzENmX/FOmWOMUJMhNe/VCS4tmWRw5AHuhO8Roh+/zvBgoJSb+y7NmuPp/z
3x8RvowfAgMBAAECggEAckTx7cxK9QLIEOaszNbhDHQLzJd71A7vcBJ2h0r/JFTC
h4yN+i2O4W2Hmr6xhHM5bOyKynpCSjCkbdLeQZhQ0GU8/wx7OWvy5HdDlcTUObK0
4M6+r00Z+7ksrElz69Pv7jY84P7Vc22QCxYaZZO74SZMlDDkpzk0e2SgAgp3FwVF
TXPa43UG4e3HPQcSN1fPP3y2omHw6RVDdpumGGVpYHdpI5FNSs84Ry0xEblOBnjn
n1EdP14WZr65+maKyv7DVaar+IbMkoX4KSJQHksO/m0xWI+B6TWsw9jHdjPP0LP1
NtClgKLKSN12X3VB/iidkHWpKb8o3lAKkCmPTZAGGQKBgQDshvGpLZ0ly9i/lllO
i2UumMZehfTSR7UoCT2EdlWU9OwZlE6KAx+b13L9unusddjcGBkSQXPmk6410sbh
3op80XYZWaMOV5vxCVXnZ26KdF47hjacqI5AbIB227cvtMCUKMrJxi056Gn/Cwa7
phAGSawrE38J4IKVOxF+tvZSzQKBgQDNpz9mXP8++jWeoDgs9uKIg8I6tQhJcCDF
vNTkwzCPtGYzjpXiyRHx3NTfnIfq4ilxFinqX4+DEeB+pXzQzJ0rQXaheFpnQTNm
zuSMYTPq9p3zKNwna3UF0fBaqdJms7iNznYgmdI5lZ0s5NRdxVEAu/Ni3Ac21E7y
gzP7q+gSmwKBgQDCrSr4eQ+wDUDgJ+pnqHnmSV50bEMeVGD5i+lzPkagbJprT1L5
ayq4BTOjPLsQLosIVFlGWlL/xCuOJ2cEfztzEp/mq412f4tdb7ah2NL16GOrEIOg
m2dCBUwTCDKVdGtRRuXp/1A4KmAbyEKJblwgIMExT0GvqncwRsbWidbiPQKBgQC5
NzfSaU842QARrRrq5C+B46i6VvDvsxzQ+hCDN4g05LRnGrPDXHPc8JaIDeIbmTTZ
tKxreUU3NpKJfWG8a4vhuUOuiUZiWEaDATK1e5XWt+XpaZNdrVnns/xUqz3jYVmF
3bxmACNl2WmFVVIuYddiYeQB1UhqCSxRHfljYJ/SoQKBgQDl2FIjqf2WGups0fL8
tkFL1+SXj57x32cf8Veodcr3XNBEsjlUd++0mAF7zA1IX1a3Y6kWJ/Wbj/oiUIiy
jr2lFzukCLvE8XvXlAf9TdZTzmijEmpDjAgBPP1fEiQHiJg0LchF2neN1hga7sk4
zghFfoBN/eiE4P63tujFkiAjFw==
-----END PRIVATE KEY-----